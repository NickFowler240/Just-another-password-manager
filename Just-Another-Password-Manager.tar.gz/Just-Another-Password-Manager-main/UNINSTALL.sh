#!/bin/bash

echo "Uninstalling Just Your Average Password Manager..."
./RMV > /dev/null 2>&1
echo "Uninstallation complete!"
echo " "
echo "You can now safely remove this folder."
echo "Just don't run the program again or you gotta uninstall again :("
