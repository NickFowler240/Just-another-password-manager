#!/bin/bash

echo "Installing Just Your Average Password Manager..."
./Build > /dev/null 2>&1
echo "Installation complete!"
echo " "
