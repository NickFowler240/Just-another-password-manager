from os.path import exists
import os

if exists(DIR) == False:
    os.system(installer)

import pwd
import getpass
import csv
import hashlib
import pyAesCrypt
import signal


i = 0
attempts = 0
user = pwd.getpwuid(os.getuid())[0]
GID = os.getgid()
UID = os.getuid()
installer = f"./INSTALLER.sh"
uninstaller = f"./UNINSTALL.sh"
DIR = f"/home/{user}/.pwbin/{UID}"
flag = f"/home/{user}/.pwbin/{UID}/flag"
Masterfile = f"/home/{user}/.pwbin/{UID}/{UID}.txt"
CSV = f"/home/{user}/.pwbin/{UID}/{UID}.csv"
ECSV = f"/home/{user}/.pwbin/{UID}/{UID}.csv.aes"

def handler(signum, frame):
    print("\nExiting...")
    quit()

signal.signal(signal.SIGINT, handler)

def quit():
    """Protocol for safely quitting program"""
    print("Bye!")
    try:
        EncodePassword()
    except ValueError:
        if exists(CSV) == True:
            print("\nWARNING: UNABLE TO ENCRYPT CSV PASSWORD FILE.")
    raise SystemExit(0)

def AddPass(password, user, site):
    """It adds a password, wow!"""
    try:
        ReadSheet("site")
    except FileNotFoundError:
        with open(CSV, 'w') as file:
            writer = csv.writer(file, delimiter=',', quotechar='"')
            writer.writerow(["site", "username", "password"])
            os.chown(CSV, UID, GID)
            os.chmod(CSV, 0o1600)
    with open(CSV, 'a') as file:
        writer = csv.writer(file, delimiter=',', quotechar='"')
        writer.writerow([site, user, password])

def Uninstall():
    """Removes main directory containing vital infrastructure for Password Manager"""
    os.system(uninstaller)
    raise SystemExit(0)

def DecodePassword():
    """Decodes CSV file"""
    pyAesCrypt.decryptFile(ECSV, CSV, master)
    os.remove(ECSV)

def EncodePassword():
    """Encodes CSV file"""
    pyAesCrypt.encryptFile(CSV, ECSV, master)
    os.remove(CSV)

def ReadSheet(site):
    """Read CSV sheet for site name"""
    with open(CSV) as data:
        read = csv.reader(data, delimiter=',')
        line = 0
        for i in read:
            if (line != 0):
                try:
                    if (i[0] == site):
                        return i
                except IndexError:
                    pass
            line += 1

def ListSheet():
    """Lists out CSV site names"""
    with open(CSV) as file:
        reader = csv.reader(file, delimiter=',')
        sites = list()
        line_count = 0
        for row in reader:
            if (line_count != 0):
                try:
                    sites.append(row[0])
                except IndexError:
                    pass
            line_count += 1
    return sites

def RemovePass(site):
    """It removes a password, wow!"""
    changes = list()
    with open(CSV) as file:
        reader = csv.reader(file, delimiter=',')
        for row in reader:
            try:
                if (row[0] != site):
                    changes.append(row)
            except IndexError:
                pass
    with open(CSV, 'w') as file:
        writer = csv.writer(file, delimiter=',', quotechar='"')
        writer.writerows(changes)

def Entry():
    """Creates flag checked for re-entry/security purposes"""
    try:
        file = open(flag, 'r+')
        line = file.read()
        if line.lower() != "true":
            file.write("true")
            return False
        else:
            return True
    except FileNotFoundError:
        file = open(flag, 'w')
        os.chown(flag, UID, GID)
        os.chmod(flag, 0o1644)

def CreateMaster():
    """Create master password"""
    if exists(flag) == True:
        print("MASTER PASSWORD CORRUPTED. PLEASE RESTORE MASTERFILE BEFORE ATTEMPTING LOGIN")
        raise SystemExit(0)
    else:
        print("No master file found. Creating a new file...")
        while i == 0:
            password = getpass.getpass("Enter new password: ")
            confirm = getpass.getpass("Confirm password: ")
            if (password != confirm):
                print("Passwords do not match. Please try again.")
            else:
                master = open(Masterfile, 'w')
                salt = hashlib.sha512((str(UID)).encode('utf-8')).hexdigest()
                hash = hashlib.sha512((salt + password).encode('utf-8')).hexdigest()
                master.write(f"{hash}")
                master.close()
                os.chmod(Masterfile, 0o1600)
                Entry()
                break

def ChangeMaster(password):
    """Changes master password"""
    master = open(Masterfile, 'w')
    salt = hashlib.sha512((str(UID)).encode('utf-8')).hexdigest()
    hash = hashlib.sha512((salt + password).encode('utf-8')).hexdigest()
    master.write(f"{hash}")
    master.close()

def CompareHash(password):
    """Compares master password hashes"""
    master = open(Masterfile)
    lines = master.read().splitlines()
    salt = hashlib.sha512((str(os.getuid())).encode('utf-8')).hexdigest()
    hash = hashlib.sha512((salt + password).encode('utf-8')).hexdigest()
    if (hash == lines[0]):
        return True
    else:
        return False

def hub():
    print("\nPlease select an item below:")
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    print("1. Add new password")
    print("2. Retrieve password")
    print("3. Delete password")
    print("4. Show stored sites")
    print("5. Change master password")
    print("6. Exit")
    print("7. Uninstall")
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~")

    selection = int(input("Enter selection (1-6): "))
    return selection

while(True):
    if exists(Masterfile) == False:
        CreateMaster()
    else:
        master = getpass.getpass("Enter master password: ")
        if (not CompareHash(master)):
            if (attempts > 2):
                print("Too many attempts.")
                raise SystemExit(0)
            else:
                print("Invalid login. Are you signed in as the correct user?")
                attempts += 1
                continue
        else:
            try:
                DecodePassword()
            except ValueError:
                pass
            break

while (i == 0):
    if Entry() == True:
        print(f"\nWelcome back, {user.title()}!")
    else:
        print(f"\nWelcome, {user.title()}!")
    try:
        choice = hub()
        if (choice > 6 or choice < 1):
            print("\nPlease enter a valid menu option.")
    except ValueError:
        print("\nPlease enter a valid menu option.")
        continue
    i = 1
    if (choice == 1):
        while (i == 1):
            print("\nType 'exit' to exit.")
            site = input("Enter site name: ")
            if (site.lower() == "site"):
                print("\nplease choose a different name...")
                continue
            elif (site.lower() == "exit"):
                i = 0
            try:
                if (ReadSheet(site) != None):
                    print("Site already exists.")
                    continue
            except FileNotFoundError:
                pass
            username = input(f"Enter username for {site.title()}: ")
            password = input(f"Enter password for {username}@{site.title()}: ")
            print("\nIs this information correct?")
            print(f"Site: {site}")
            print(f"Username: {username}")
            print(f"Password: {password}")
            i = 2
            while i == 2:
                check = input("(Yes/No) ")
                if check.lower() == "no":
                    i = 1
                elif check.lower() == "yes":
                    print(f"\nAdding new entry to database...")
                    AddPass(password, username, site)
                    print(f"New Entry added for site: {site.title()}")
                    i = 3
                    while i == 3:
                        cont = input("\nAdd another password? (y/n) ")
                        if cont.lower() == "y":
                            i = 1
                        elif cont.lower() == "n":
                            exit = input("\nReturn to main menu? (y/n) ")
                            if exit == 'y':
                                i = 0
                            elif exit == 'n':
                                quit()
                            else:
                                print("Invalid selection.")
                        else:
                            print("Invalid selection.")
                elif check.lower() != "yes" or check.lower() != "no":
                    print("Invalid option.")
                    continue

    if (choice == 2):
        while i == 1:
            print("\nType 'exit' to exit.")
            site = input("Enter site name to retrieve: ")
            if (site.lower() == "site"):
                print("Invalid name.")
            elif (site.lower() == "exit"):
                i = 0
            try:
                if (ReadSheet(site) == None):
                    print("Site not found.")
                    continue
                else:
                    row = ReadSheet(site)
                    print("\n")
                    print(f"Site: {row[0]}")
                    print(f"Username: {row[1]}")
                    print(f"Password: {row[2]}")
                    i = 2
                    while i == 2:
                        cont = input("\nRetrieve another password? (y/n) ")
                        if cont.lower() == "y":
                            i = 1
                        elif cont.lower() == "n":
                            exit = input("\nReturn to main menu? (y/n) ")
                            if exit == 'y':
                                i = 0
                            elif exit == 'n':
                                quit()
                            else:
                                print("Invalid selection.")
                        else:
                            print("Invalid selection.")
            except FileNotFoundError:
                print("Password file not found.")
                i = 0

    if (choice == 3):
        while i == 1:
            print("\nType 'exit' to exit.")
            site = input("Enter site to delete: ")
            if (site.lower() == "site"):
                print("Invalid name.")
            elif (site.lower() == "exit"):
                i = 0
            elif (ReadSheet(site) == None):
                print("No site found.")
            else:
                name = ReadSheet(site)
                choice = input(f"Are you sure you want to delete password for {name[1]}@{site.title()}? (yes/no) ")
                if choice.lower() == 'yes':
                    RemovePass(site)
                    print(f"Info for {name[1]}@{site.title()} has been deleted.")
                    i = 2
                    while i == 2:
                        cont = input("\nDelete another password? (y/n) ")
                        if cont.lower() == "y":
                            i = 1
                        elif cont.lower() == "n":
                            exit = input("\nReturn to main menu? (y/n) ")
                            if exit == 'y':
                                i = 0
                            elif exit == 'n':
                                quit()
                            else:
                                print("Invalid selection.")
                        else:
                            print("Invalid selection.")
                elif choice.lower() == 'no':
                    print("Returning to menu...")
                    i = 0
                else:
                    print("Invalid selection.")

    if (choice == 4):
        try:
            if (ListSheet()):
                counter = 1
                print("\n\nSites stored:")
                print("----------------")
                for site in ListSheet():
                    print(f"{counter}: {site}")
                    counter += 1
                    print("\n")
            else:
                print("\nNo sites avaliable.")
            i = 0
        except FileNotFoundError:
            print("No password file found. Have you added any passwords yet?")
            i = 0

    if (choice == 5):
        while i == 1:
            print("Type 'exit' to exit.")
            insert = getpass.getpass("Enter current password: ")
            if (not CompareHash(insert)):
                print("Incorrect password. Please try again.")
            elif insert.lower() == 'exit':
                i = 0
            else:
                master = getpass.getpass("Enter new password: ")
                confirm = getpass.getpass("Confirm password: ")
                if (master != confirm):
                    print("Passwords do not match. Please try again.")
                else:
                    ChangeMaster(master)
                    print("\n-------------------------------------")
                    print("Master password successfully changed!")
                    print("-------------------------------------")
                    i = 0

    if (choice == 6):
        quit()

    if (choice == 7):
        while i == 1:
            uninstall = input("Are you sure you want to uninstall? (y/n) ")
            if uninstall.lower() == "y":
                Uninstall()
                quit()
            if uninstall.lower() == "n":
                i = 0
