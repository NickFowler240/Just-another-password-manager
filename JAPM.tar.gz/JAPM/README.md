INSTALLATION:
Simply run pwmgr.py to install.
If you run into an error, run installer.sh seperately from script and try again.

Thank you for using Just Your Average Password Manager :)
